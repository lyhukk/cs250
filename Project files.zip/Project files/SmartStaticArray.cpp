#include "SmartStaticArray.hpp"

#include "cuTEST/Menu.hpp"

SmartStaticArray::SmartStaticArray()
{
	m_itemCount = 0;
}

bool SmartStaticArray::Push( const string& newItem )
{
	if (m_itemCount == MAX_SIZE)
		return false;
	m_data[m_itemCount] = newItem;
	m_itemCount++;
	return true;
}


bool SmartStaticArray::Insert( int index, const string& newItem )
{
	if (m_itemCount == MAX_SIZE)
		return false;
	if (index < 0 || index > m_itemCount)
		return false;
	if (index == m_itemCount)
	{
		return Push(newItem);
	}
	for (int i = m_itemCount; i > index; i--)
	{
		m_data[i] = m_data[i - 1];
	}
	m_data[index] = newItem;
	m_itemCount++;
	return true;
}


bool SmartStaticArray::Extend( const SmartStaticArray& other )
{
	if (IsFull())
		return false;
	if ((m_itemCount + other.Size()) > MAX_SIZE)
		return false;
	if (other.IsEmpty())
		return false;
	for (int i = 0; i < other.Size(); i++)
	{
		m_data[m_itemCount + i] = other.Get(i);
	}
	m_itemCount += other.Size();
	return true;
}


bool SmartStaticArray::Pop()
{
	if (IsEmpty())
		return false;
	m_itemCount--;
	return true;
}


bool SmartStaticArray::Remove( int index )
{
	if (index < 0 || index >= m_itemCount)
		return false;
	for (int i = index; i < m_itemCount -1; i++)
	{
		m_data[i] = m_data[i + 1];
	}
	m_itemCount--;
	return true;
}


string SmartStaticArray::Get( int index ) const
{
	if (index < 0 || index >= m_itemCount)
		return "";
	return m_data[index];
}


int SmartStaticArray::Size() const
{
	return m_itemCount;
}


bool SmartStaticArray::IsFull() const
{
	return m_itemCount == MAX_SIZE;
}

bool SmartStaticArray::IsEmpty() const
{
	return m_itemCount == 0;
}


string SmartStaticArray::operator[]( int index )
{
	if (index < 0 || index >= m_itemCount)
		return NULL;
	return m_data[index];
}


SmartStaticArray& SmartStaticArray::operator=( const SmartStaticArray& other )
{
	if (other.IsEmpty())
	{
		SmartStaticArray temp;
		return temp;
	}
	for (int i = 0; i < other.Size(); i++)
	{
		m_data[i] = other.Get(i);
	}
	m_itemCount = other.Size();
    return *this;
}

bool SmartStaticArray::operator==( const SmartStaticArray& other )
{
	if (this == &other)
		return true;
	if (other.IsEmpty() && IsEmpty())
		return true;
	if (m_itemCount != other.Size())
		return false;
	for (int i = 0; i < m_itemCount; i++)
	{
		if (m_data[i].compare(other.Get(i)) != 0)
			return false;
	}
	return true;
}


bool SmartStaticArray::operator!=( const SmartStaticArray& other )
{
	return !( *this == other );
}
