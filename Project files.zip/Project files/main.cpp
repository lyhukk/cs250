#include <iostream>
using namespace std;

#include "Tester.hpp"

int main()
{
    Tester tester;
    tester.Start();

	/*
	SmartDynamicArray t1;
	t1.Push("A");
	t1.Push("B");
	SmartDynamicArray t2;
	t2 = t1;
	cout <<"Size: " << t2.Size() << endl;
	for (int i = 0; i < t2.Size(); i++)
	{
		cout << t2.Get(i) << " ";
	}
	cout << endl;
*/
    return 0;
}
