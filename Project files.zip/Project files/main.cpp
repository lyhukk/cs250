#include <iostream>
using namespace std;

#include "Tester.hpp"

int main()
{
    Tester tester;
    tester.Start();
	
    return 0;
}

