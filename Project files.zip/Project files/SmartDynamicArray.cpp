#include "SmartDynamicArray.hpp"

#include "cuTEST/Menu.hpp"

SmartDynamicArray::SmartDynamicArray()
{
	m_itemCount = 0;
	m_arraySize = 0;
	m_data = nullptr;
}

SmartDynamicArray::~SmartDynamicArray()
{
	if (m_data != nullptr)
		delete[] m_data;
}

bool SmartDynamicArray::Push( const string& newItem )
{
	if (m_data == nullptr || IsFull())
		Resize();
	m_data[m_itemCount] = newItem;
	m_itemCount++;
	return true;
}


bool SmartDynamicArray::Insert( int index, const string& newItem )
{
	if (index < 0 || index > m_itemCount)
		return false;
	if (m_data == nullptr || IsFull())
		Resize();
	if (index == m_itemCount)
	{
		m_data[index] = newItem;
		m_itemCount++;
		return true;
	}
	for (int i = m_itemCount; i > index; i--)
	{
		m_data[i] = m_data[i - 1];
	}
	m_data[index] = newItem;
	m_itemCount++;
	return true;
}


bool SmartDynamicArray::Extend( const SmartDynamicArray& other )
{	
	if (other.IsEmpty())
		return false;
	int temp = m_itemCount;
	if (m_data == nullptr || m_arraySize < (temp + other.Size()))
		Resize(temp + other.Size());
	for (int i = 0; i < other.Size(); i++)
	{
		m_data[temp + i] = other.Get(i);
	}
	m_itemCount = temp + other.Size();
	return true;
}


bool SmartDynamicArray::Pop()
{
	if (IsEmpty())
		return false;
	m_itemCount--;
	return true;
}


bool SmartDynamicArray::Remove( int index )
{
	if (IsEmpty())
		return false;
	if (index < 0 || index > m_itemCount - 1)
		return false;
	if (index == m_itemCount - 1)
	{
		m_itemCount--;
		return true;
	}
	for (int i = index; i < m_itemCount - 1; i++)
	{
		m_data[i] = m_data[i + 1];
	}
	m_itemCount--;
	return true;
}


string SmartDynamicArray::Get( int index ) const
{
	if (index < 0 || index > m_itemCount - 1)
		return "";
	if (IsEmpty())
		return "";
	return m_data[index];
}


int SmartDynamicArray::Size() const
{
	if (IsEmpty())
		return 0;
	return m_itemCount;
}

int SmartDynamicArray::GetMaxSize() const
{
	return m_arraySize;
}

bool SmartDynamicArray::IsFull() const
{
	return m_itemCount == m_arraySize;
}

bool SmartDynamicArray::IsEmpty() const
{
	return  m_data == nullptr || m_itemCount == 0;
}

string SmartDynamicArray::operator[]( int index )
{
	return Get(index);
}

SmartDynamicArray& SmartDynamicArray::operator=( const SmartDynamicArray& other )
{
	Free();
	Resize(other.Size());
	for (int i = 0; i < other.Size(); i++)
	{
		m_data[i] = other.Get(i);
	}
	m_itemCount = other.Size();
    return *this;
}

bool SmartDynamicArray::operator==( const SmartDynamicArray& other )
{
	if (IsEmpty() && other.IsEmpty())
		return true;
	if (IsEmpty() || other.IsEmpty())
		return false;
	if (Size() != other.Size())
		return false;
	for (int i = 0; i < m_itemCount; i++)
	{
		if (m_data[i].compare(other.Get(i)) != 0)
		{
			return false;
		}
	}
	return true;
}


bool SmartDynamicArray::operator!=( const SmartDynamicArray& other )
{
	return !(*this == other);
}

void SmartDynamicArray::Free()
{
	if (m_data == nullptr) 
	{
		return;
	}
	m_itemCount = 0;
	m_arraySize = 0;
	delete[]m_data;
	m_data = nullptr;
}

void SmartDynamicArray::Resize()
{
	Resize(m_arraySize + 10);
}


void SmartDynamicArray::Resize( int newSize )
{
	if (m_arraySize >= newSize)
		return;
	string* temp;
	m_arraySize = newSize;
	temp = new string[newSize];
	if (m_data != nullptr) 
	{
		for (int i = 0; i < m_itemCount; i++) {
			temp[i] = m_data[i];
		}
		delete[] m_data;
	}	
	m_data = temp;
}




