
#include "stdafx.h"
#include <iostream>
#include <string>
#include <stack>
#include <vector>
using namespace std;

class Book
{
    public:
    Book( const string& title ) 
    { 
        m_title = title;
        m_checkedIn = false; 
    }
    
    void CheckIn()
    {
        cout << "Checked in \"" << m_title << "\""<< endl;
        m_checkedIn = true;
    }
    
    private:
    string m_title;
    bool m_checkedIn;
};

int main()
{
    // Create a stack of Book objects called bookDrop.
    stack<Book> bookDrop;
    
    // Push a series of books into the bookDrop.   
	bookDrop.push(Book("A"));
	bookDrop.push(Book("B"));
	bookDrop.push(Book("C"));
	bookDrop.push(Book("D"));
	bookDrop.push(Book("E"));
	bookDrop.push(Book("F"));
    vector<Book> bookPool;
    
    // Go through the stack of books using a while loop,
    // while the stack is not empty...
    // Take the top-most book, and push it into the bookPool.
    // Then pop the top book off the bookDrop.
	while (!bookDrop.empty())
	{
		bookPool.push_back(bookDrop.top());
		bookDrop.pop();
	}
	cout << "Books in the pool: " << endl;
	// print out the book title in the bookpool
	for (Book e : bookPool)
	{
		e.CheckIn();
	}
    return 0;
}
