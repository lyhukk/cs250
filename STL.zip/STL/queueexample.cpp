
#include "stdafx.h"
#include <iostream>
#include <string>
#include <queue>
using namespace std;

int main()
{
    float balance = 0.0;
    // Create a queue of floats, named transactions
	queue<float> transactions;
    // Push some + and - floats into the transactions queue.
	transactions.push(1.0);
	transactions.push(2.3);
	transactions.push(-1.0);
	transactions.push(1.5);
	transactions.push(-2.5);
    // Loop through all the transactions - while the queue is empty.
    // Within the loop, whatever amount is at the front of the queue,
    // add it to the balance and then pop it off the queue.
	while (!transactions.empty()) 
	{
		balance += transactions.front();
		transactions.pop();
	}
	
    cout << "Final balance: $" << balance << endl;
    
    return 0;
}
