#ifndef SORTEDlIST_H
#define SORTEDLIST_H
#include <iostream>
#include <stdexcept>
#include <string>

using namespace std;

// Node class
template <typename T>
class Node {
public:
	Node(T data) {
		next = nullptr;
		prev = nullptr;
		this->data = data;
	}
	// comparator
	bool operator < (const Node<T>* other)
	{
		return (this->data < other->data);
	}
	Node<T>* next;
	Node<T>* prev;
	T data;
};

// class list
template <typename T>
class SortedList {
public:
	SortedList();
	~SortedList();
	bool isEmpty();
	int size();
	void sortedPush(T data);
	T getAt(int pos);
	void pop();
	void display();
private:
	Node<T>* front;		// the beginning of list
	Node<T>* end;		// the end of list
	int itemsCount;		// items number in list
};
template <typename T>
SortedList<T>::SortedList()
{
	front = nullptr;
	end = nullptr;
	itemsCount = 0;
}
template <typename T>
SortedList<T>::~SortedList()
{
	while (!isEmpty())
	{
		pop();
	}
}
template <typename T>
bool SortedList<T>::isEmpty()
{
	return itemsCount == 0;
}
template <typename T>
int SortedList<T>::size()
{
	return itemsCount;
}
template <typename T>
void SortedList<T>::sortedPush(T data)
{
	if (isEmpty())
	{
		Node<T>* temp = new Node<T>(data);
		front = temp;
		end = temp;
		itemsCount = 1;
		return;
	}
	Node<T>* curr = front;
	while (curr != nullptr && curr->data < data)
	{
		curr = curr->next;
	}
	// insert to front
	if (curr == front)
	{
		Node<T>* temp = new Node<T>(data);
		front->prev = temp;
		temp->next = front;
		front = temp;
		itemsCount++;
		return;
	} 
	// insert to end
	if (curr == nullptr)
	{
		Node<T>* temp = new Node<T>(data);
		temp->prev = end;
		end->next = temp;
		end = temp;
		itemsCount++;
		return;
	}
	// insert in middle
	Node<T>* temp = new Node<T>(data);
	Node<T>* bef = curr->prev;
	bef->next = temp;
	temp->prev = bef;
	temp->next = curr;
	curr->prev = temp;	
	itemsCount++;
	return;
}
template <typename T>
T SortedList<T>::getAt(int pos)
{
	if (isEmpty())
	{
		throw out_of_range("Empty list!");
	}
	if (pos < 0 || pos >= itemsCount)
	{
		throw out_of_range("Out of boundary!");
	}
	if (pos == 0)
		return front->data;
	if (pos == itemsCount - 1)
		return end->data;
	int count = 0;
	Node<T>* curr = front;
	while (curr != end && count < pos)
	{
		curr = curr->next;
		count++;
	}
	return curr->data;
}
template <typename T>
void SortedList<T>::pop()
{
	if (isEmpty())
		return;
	if (itemsCount == 1)
	{
		Node<T>* temp = end;
		front = nullptr;
		end = nullptr;
		itemsCount = 0;
		delete temp;
		return;
	}
	Node<T>* temp = end;
	end = end->prev;
	end->next = nullptr;
	temp->prev = nullptr;
	delete temp;
	itemsCount--;
}
template <typename T>
void SortedList<T>::display()
{
	if (isEmpty())
	{
		cout << "Empty list.\n";
		return;
	}
	Node<T>* curr = front;
	cout << "The list: ";
	while (curr != nullptr)
	{
		cout << curr->data << " ";
		curr = curr->next;
	}
	cout << endl;
}
#endif // !SORTEDlIST_H