// SortedList.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "SortedList.h"

using namespace std;

bool testSize();
bool testGet();
bool testPush();
int main()
{
	bool finish = false;
	int choice;
	while (!finish) {
		cout << "Testing: \n";
		cout << "\t1 for test size(): \n";
		cout << "\t2 for test getAt(): \n";
		cout << "\t3 for test sortedPush(): \n";
		cout << "\t4 to quit: \n";
		cout << "\tPlease choose: \t";
		cin >> choice;
		cout << endl;
		switch (choice)
		{
		case 1 :
			testSize();
			break;
		case 2:
			testGet();
			break;
		case 3 :
			testPush();
			break;

		default:
			finish = true;
			break;
		}
		cout << endl;
	}
	
    return 0;
} // end main

bool testSize()
{
	cout << "\nTesting size(): \n";
	SortedList<int> sl1;
	if (sl1.size() != 0) 
	{
		cout << "The size is not 0." << endl;
		return false;
	}
	sl1.sortedPush(1);
	sl1.display();
	if (sl1.size() != 1)
	{
		cout << "The size is not 1." << endl;
		return false;
	}
	sl1.sortedPush(3);
	sl1.display();
	sl1.sortedPush(5);
	sl1.display();
	sl1.sortedPush(4);
	sl1.display();
	sl1.sortedPush(2);
	sl1.display();
	if (sl1.size() != 5)
	{
		cout << "The size is not 5." << endl;
		return false;
	}

	cout << "Testing of size() passed." << endl;
}
bool testGet()
{
	cout << "\nTesting getAt(): \n";
	SortedList<string> sl2;
	sl2.sortedPush("A");
	sl2.display();
	if (sl2.getAt(0) != "A")
	{
		cout << "position 0 should be A." << endl;
		return false;
	}	
	sl2.sortedPush("B");
	sl2.display();
	if (sl2.getAt(0) != "A")
	{
		cout << "position 0 should be A." << endl;
		return false;
	}
	if (sl2.getAt(1) != "B")
	{
		cout << "position 1 should be B." << endl;
		return false;
	}
	sl2.sortedPush("C");
	sl2.display();
	if (sl2.getAt(2) != "C")
	{
		cout << "Position 2 should be C." << endl;
		return false;
	}
	cout << "You passed getAt() testing.\n";
	return true;
}
bool testPush()
{
	cout << "\nTesting sortedPush(): \n";
	SortedList<string> sl3;
	sl3.sortedPush("E");
	sl3.display();
	if (sl3.getAt(0) != "E")
	{
		cout << "position 0 should be E." << endl;
		return false;
	}
	sl3.sortedPush("A");
	sl3.display();
	if (sl3.getAt(0) != "A")
	{
		cout << "position 0 should be A." << endl;
		return false;
	}
	if (sl3.getAt(1) != "E")
	{
		cout << "position 1 should be E." << endl;
		return false;
	}
	sl3.sortedPush("B");
	sl3.display();
	if (sl3.getAt(1) != "B")
	{
		cout << "Position 1 should be B." << endl;
		cout << sl3.getAt(1) << endl;
		return false;
	}
	cout << "You passed sortedPush() testing.\n";
	return true;
}