#ifndef _TESTER_HPP
#define _TESTER_HPP

#include <iostream>
#include <string>
using namespace std;

#include "cuTEST/TesterBase.hpp"
#include "cuTEST/Menu.hpp"
#include "cuTEST/StringUtil.hpp"

#include "hp4_program.hpp"

class Tester : public TesterBase
{
public:
	Tester()
	{
		AddTest(TestListItem("ExampleTest()",             bind(&Tester::ExampleTest, this)));
		AddTest(TestListItem("ExampleTest()",             bind(&Tester::ExampleTest, this)));
	}

	virtual ~Tester()
	{
	}

private:
	int ExampleTest();
};

int Tester::ExampleTest()
{
    InitTest( "ExampleTest", { "Prerequisite1", "Prerequisite2" } );

    StartTest( "This_is_test_1" );
    if ( 0 == 1 )
    {
        TestFail();
        ReportFailure( "ExampleTest_Test1", "0_equal_to_1" );
    }
    else if ( 0 == 2 )
    {
        TestFail();
        ReportFailure( "ExampleTest_Test1", "0_equal_to_1" );
    }
    else
    {
        TestPass();
    }

    DisplayScore();
    return TestResult();
}

#endif
