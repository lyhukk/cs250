/*
INCLUDE THIS FILE WITH THE PROJECT.
TO RUN PROJECT, USE ITS FILE WITH main() IN IT,
OR TO RUN TESTS, USE THIS FILE.
*/

#include <iostream>
using namespace std;

#include "../Tester.hpp"

int main()
{
    Tester test;
    test.Start();

    return 0;
}
