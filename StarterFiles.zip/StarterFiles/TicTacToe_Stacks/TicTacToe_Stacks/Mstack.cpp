#include <stdexcept>
#include <iostream>

template<typename T> class Node
{
public:
	Node(T data)
	{
		this->data = data;
		ptrNext = nullptr;
		ptrPrev = nullptr;
	}
public:
	T data;
	Node<T>* ptrNext;
	Node<T>* ptrPrev;
};



template<typename T> 
class Mstack
{
public:
	Mstack();
	~Mstack();
	int size();
	void push(T data);
	void pop();
	T top();
private:
	int itemCounts;
	Node<T>* ptrFront;
	Node<T>* ptrEnd;
};
template<typename T>
Mstack<T>::Mstack()
{
	itemCounts = 0;
	ptrFront = nullptr;
	ptrEnd = nullptr;
}
template<typename T>
Mstack<T>::~Mstack()
{
	while (itemCounts > 0)
	{
		pop();
	}
}
template<typename T>
int Mstack<T>::size()
{
	return itemCounts;
}
template<typename T>
void Mstack<T>::push(T data)
{
	Node<T>* temp = new Node<T>(data);
	if (itemCounts == 0)
	{
		ptrFront = temp;
		ptrEnd = temp;
		itemCounts = 1;
		return;
	}
	ptrEnd->ptrNext = temp;
	temp->ptrPrev = ptrEnd;
	ptrEnd = temp;
	itemCounts++;
}
template<typename T>
void Mstack<T>::pop()
{
	if (itemCounts == 0)
	{
		throw std::out_of_range("Empty stack!");
	}
	if (itemCounts == 1)
	{
		Node<T>* temp = ptrEnd;
		ptrFront = nullptr;
		ptrEnd = nullptr;
		delete temp;
		itemCounts = 0;
		std::cout << "Current size: " << itemCounts << endl;
		return;
	}
	Node<T>* temp = ptrEnd;
	ptrEnd = temp->ptrPrev;
	ptrEnd->ptrNext = nullptr;
	temp->ptrPrev = nullptr;
	delete temp;
	itemCounts--;
	std::cout << "Current size: " << itemCounts << endl;
}
template<typename T>
T Mstack<T>::top()
{
	if (itemCounts == 0)
	{
		throw std::out_of_range("Empty stack!");
	}
	return ptrEnd->data;
}