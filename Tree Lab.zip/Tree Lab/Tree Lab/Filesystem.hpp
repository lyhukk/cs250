#ifndef Filesystem_HPP
#define Filesystem_HPP

#include <iostream>
#include <vector>
#include <list>
using namespace std;

#include "StringUtil.hpp"

struct File
{
	File()
	{
		isDirectory = false;
		ptrParent = nullptr;
	}

	~File()
	{
        for ( unsigned int i = 0; i < childrenPtrs.size(); i++ )
        {
            delete childrenPtrs[i];
        }
	}

	vector<File*> childrenPtrs;
	File* ptrParent;

	bool isDirectory; // traversible
	string name;
};

class Filesystem
{
public:
    // public interfaces
    File* Find( const string& filename )
    {
        return Find( filename, m_ptrRoot );
    }

    File* GetFile( const list<string>& path, const string& filename )
    {
        return GetFile( path, filename, m_ptrRoot );
    }

private:
    // ** Implement these **
    File* Find( const string& filename, File* ptrLookAt )
    {
		// when is empty
		if (ptrLookAt == nullptr) 
		{
			return nullptr;
		}
		// when is a directory, search all elements in that directory recursively
		if (ptrLookAt->isDirectory) 
		{
			if (ptrLookAt->childrenPtrs.empty())
			{
				return nullptr;
			}
			else
			{
				File* temp = nullptr;
				for (unsigned int i = 0; i < ptrLookAt->childrenPtrs.size(); i++)
				{
					temp = nullptr;
					temp = Find(filename, ptrLookAt->childrenPtrs[i]);
					if (temp != nullptr)
					{
						return temp;
					}
				}
				// not found
				return nullptr;
			}
			
		}
		// if find the correct file
		else if (ptrLookAt->name.compare(filename) == 0) {
			return ptrLookAt;
		}
		// if file is not 
		else
		{
		 return nullptr;
		}
    }

    File* GetFile( list<string> path, const string& filename, File* current )
    {
		if (current == nullptr)
		{
			return nullptr;
		}
		// if is a diretory, search the folder elements
		if (current->isDirectory)
		{
			// if a folder is empty, return nullptr
			if (current->childrenPtrs.empty())
			{
				return nullptr;
			}
			File* temp = nullptr;
			// move path to next level
			path.pop_front();
			for (unsigned int i = 0; i < current->childrenPtrs.size(); i++)
			{
				temp = nullptr;
				// if is a folder, check if it is in the correct path
				// if correct, recursively GetFile()
				// if found, return the correct place
				if (current->childrenPtrs[i]->isDirectory 
					&& current->childrenPtrs[i]->name.compare(path.front()) == 0)
				{
					temp = GetFile(path, filename, current->childrenPtrs[i]);
					if (temp != nullptr)
					{
						return temp;
					}
				}
				// if not a folder, and the filename is what we want, return current folder
				else if (!(current->childrenPtrs[i]->isDirectory) 
					&& current->childrenPtrs[i]->name.compare(filename) == 0)
				{
					return current;
				}
			}
			// if not found
			return nullptr;
		}
		// find the correct one, return parent
		else if (filename.compare(current->name) == 0)
		{
			return current->ptrParent;
		}
		else 
		{
			return nullptr;
		}      
    }

public:
    // Constructor / destructor
	Filesystem()
	{
		m_nodeCount = 0;
		CreateFilesystem();
	}

	~Filesystem()
	{
        delete m_ptrRoot;
	}

    // Recursive function
	string GetPath( File* ptrFile )
	{
        if ( ptrFile == nullptr )
        {
            return "";
        }

        return GetPath( ptrFile->ptrParent ) + " / " + ptrFile->name;
	}

	// Get size
	int GetSize()
	{
        return m_nodeCount;
	}

private:
    // Create data for our lab
	void CreateFilesystem()
	{
        // Create root
        m_ptrRoot = new File;
        m_ptrRoot->isDirectory = true;
        m_ptrRoot->name = "ROOT";
        m_nodeCount++;

        cout << GetPath( m_ptrRoot ) << endl;

        // Create a few files
        for ( int i = 0; i < 3; i++ )
        {
            File* newFile = new File;
            newFile->isDirectory = false;
            newFile->name = "file-" + StringUtil::ToString( i ) + ".txt";
            newFile->ptrParent = m_ptrRoot;
            m_ptrRoot->childrenPtrs.push_back( newFile );
            m_nodeCount++;

            cout << GetPath( newFile ) << endl;
        }

        // Create a few folders
        for ( int i = 0; i < 2; i++ )
        {
            File* newFile = new File;
            newFile->isDirectory = true;
            newFile->name = "folder-" + StringUtil::ToString( i );
            newFile->ptrParent = m_ptrRoot;
            m_ptrRoot->childrenPtrs.push_back( newFile );
            m_nodeCount++;

            cout << GetPath( newFile ) << endl;
        }

        // Create files and folders for subfolders
        for ( unsigned int i = 0; i < m_ptrRoot->childrenPtrs.size(); i++ )
        {
            if ( m_ptrRoot->childrenPtrs[i]->isDirectory )
            {
                // Folder
                File* newFolder = new File;
                newFolder->isDirectory = true;
                string letter = "";
                letter += char( 65 + i );
                newFolder->name = "folder-" + letter;
                newFolder->ptrParent = m_ptrRoot->childrenPtrs[i];
                m_ptrRoot->childrenPtrs[i]->childrenPtrs.push_back( newFolder );
                m_nodeCount++;

                cout << GetPath( newFolder ) << endl;

                // Files
                for ( int i = 0; i < 3; i++ )
                {
                    File* newFile = new File;
                    newFile->isDirectory = false;
                    letter = "";
                    letter += char( 65 + i );
                    newFile->name = "file-" + letter + ".txt";
                    newFile->ptrParent = m_ptrRoot->childrenPtrs[i];
                    m_ptrRoot->childrenPtrs[i]->childrenPtrs.push_back( newFile );
                    m_nodeCount++;

                    cout << GetPath( newFile ) << endl;
                }

                // Create file in this folder
                File* newFile = new File;
                newFile->isDirectory = false;
                letter = "";
                letter += char( 65 + i );
                newFile->name = "file-" + letter + ".txt";
                newFile->ptrParent = m_ptrRoot->childrenPtrs[i]->childrenPtrs[0];
                m_ptrRoot->childrenPtrs[i]->childrenPtrs[0]->childrenPtrs.push_back( newFile );
                m_nodeCount++;

                cout << GetPath( newFile ) << endl;
            }
        }

        cout << "Total nodes: " << GetSize() << endl << endl;
	}

private:
	File* m_ptrRoot;
	int m_nodeCount;
};

#endif
